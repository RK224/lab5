#include "student.h"
#ifndef _STUDENTS
#define _STUDENTS
	typedef struct element{
	key k ;
}element;

typedef struct key{
	float data ;
}key ;
#endif




