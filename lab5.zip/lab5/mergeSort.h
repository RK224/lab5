#include "element.h"

void merge(element* ls1 , int size1 , element* ls2 , int size2 , element* ls);
void mergeSort(element* ls,int low , int high);
